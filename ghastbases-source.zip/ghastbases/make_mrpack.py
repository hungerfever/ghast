#!/usr/bin/env python3
"""Build the mod and package it as a Modrinth modpack (.mrpack) you can import into the Modrinth App.

    python make_mrpack.py              # builds the jar with Gradle, then writes ghastbases-<version>.mrpack
    python make_mrpack.py --skip-build # reuse an existing jar in build/libs

Needs JDK 25 on PATH (for Gradle) and internet access (Gradle downloads, plus one Modrinth API call that
looks up the Fabric API file to put in the pack).
"""
import argparse
import glob
import json
import os
import subprocess
import sys
import urllib.parse
import urllib.request
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))


def read_props():
    props = {}
    with open(os.path.join(ROOT, "gradle.properties"), encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                props[k.strip()] = v.strip()
    return props


def fabric_api_file(mc_version, wanted_version):
    """Ask Modrinth for the Fabric API file so the pack downloads it (hashes come from the API)."""
    q = urllib.parse.urlencode({"game_versions": json.dumps([mc_version]), "loaders": json.dumps(["fabric"])})
    req = urllib.request.Request(
        f"https://api.modrinth.com/v2/project/fabric-api/version?{q}",
        headers={"User-Agent": "ghastbases-packager/1.0"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        versions = json.load(resp)
    if not versions:
        sys.exit(f"Modrinth has no Fabric API build for Minecraft {mc_version}.")
    v = next((x for x in versions if x["version_number"] == wanted_version), versions[0])
    f = next((f for f in v["files"] if f.get("primary")), v["files"][0])
    return {
        "path": "mods/" + f["filename"],
        "hashes": {"sha1": f["hashes"]["sha1"], "sha512": f["hashes"]["sha512"]},
        "env": {"client": "required", "server": "required"},
        "downloads": [f["url"]],
        "fileSize": f["size"],
    }


def build_jar():
    gradlew = "gradlew.bat" if os.name == "nt" else "./gradlew"
    subprocess.run([gradlew, "build"], cwd=ROOT, check=True, shell=(os.name == "nt"))


def find_jar(version):
    jars = [
        j for j in glob.glob(os.path.join(ROOT, "build", "libs", "*.jar"))
        if not j.endswith(("-sources.jar", "-dev.jar", "-javadoc.jar"))
    ]
    if not jars:
        sys.exit("No jar found in build/libs. Did the Gradle build succeed?")
    return max(jars, key=os.path.getmtime)


def write_pack(jar, props, api_file, out):
    index = {
        "formatVersion": 1,
        "game": "minecraft",
        "versionId": props["mod_version"],
        "name": "Ghast Bases",
        "summary": "Build bases on happy ghasts and steer them with a wheel.",
        "files": [api_file],
        "dependencies": {
            "minecraft": props["minecraft_version"],
            "fabric-loader": props["loader_version"],
        },
    }
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("modrinth.index.json", json.dumps(index, indent=2))
        z.write(jar, "overrides/mods/" + os.path.basename(jar))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-build", action="store_true")
    args = ap.parse_args()

    props = read_props()
    if not args.skip_build:
        build_jar()
    jar = find_jar(props["mod_version"])
    api_file = fabric_api_file(props["minecraft_version"], props["fabric_api_version"])
    out = os.path.join(ROOT, f"ghastbases-{props['mod_version']}.mrpack")
    write_pack(jar, props, api_file, out)
    print(f"\nDone: {out}\nModrinth App: Add instance > Import from file > pick that .mrpack")


if __name__ == "__main__":
    main()
