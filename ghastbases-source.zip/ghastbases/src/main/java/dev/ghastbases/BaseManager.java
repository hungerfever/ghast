package dev.ghastbases;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * A "base" is a set of ordinary blocks that rides above a happy ghast. The blocks are real world blocks:
 * whenever the ghast crosses into a new block cell, the whole set is lifted and put down one step over.
 *
 * Layout (relative to the ghast's block cell): a (2R+1) x (2R+1) footprint, starting Y0 blocks above the
 * ghast's feet and H blocks tall. Y0 = 5 keeps the base just above the ghast's 4-block-tall body.
 */
public final class BaseManager {
	public static final int R = 6;
	public static final int Y0 = 5;
	public static final int H = 12;
	private static final double MAX_SPEED = 0.45;
	private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

	/** player -> ghast the player's wheel steers */
	private static final Map<UUID, UUID> LINKS = new HashMap<>();
	/** ghast -> its base */
	private static final Map<UUID, Base> BASES = new HashMap<>();

	private static final class Base {
		final ServerLevel level;
		final Map<BlockPos, BlockState> blocks = new HashMap<>(); // keys are relative to origin
		final List<BlockPos> pending = new ArrayList<>();
		BlockPos origin;
		Vec3 vel = Vec3.ZERO;
		Vec3 lastGood;

		Base(ServerLevel level, Entity ghast) {
			this.level = level;
			this.origin = originOf(ghast.position());
			this.lastGood = ghast.position();
		}
	}

	private BaseManager() {}

	public static void clear() {
		LINKS.clear();
		BASES.clear();
	}

	// ---------------------------------------------------------------- helpers

	private static BlockPos originOf(Vec3 p) {
		return new BlockPos(Mth.floor(p.x), Mth.floor(p.y), Mth.floor(p.z));
	}

	private static boolean inRegion(BlockPos rel) {
		return Math.abs(rel.getX()) <= R && Math.abs(rel.getZ()) <= R
			&& rel.getY() >= Y0 && rel.getY() < Y0 + H;
	}

	private static boolean capturable(BlockState s) {
		return !s.isAir() && !s.hasBlockEntity() && s.getFluidState().isEmpty();
	}

	private static boolean regionLoaded(ServerLevel level, BlockPos origin) {
		return level.hasChunksAt(origin.offset(-R, Y0, -R), origin.offset(R, Y0 + H, R));
	}

	/** Re-read the world: forget blocks that were broken, pick up changed block states. */
	private static void refresh(Base base) {
		Iterator<Map.Entry<BlockPos, BlockState>> it = base.blocks.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<BlockPos, BlockState> e = it.next();
			BlockState actual = base.level.getBlockState(base.origin.offset(e.getKey()));
			if (!capturable(actual)) {
				it.remove();
			} else {
				e.setValue(actual);
			}
		}
	}

	private static void processPending(Base base) {
		for (BlockPos rel : base.pending) {
			if (inRegion(rel) && !base.blocks.containsKey(rel)) {
				BlockState s = base.level.getBlockState(base.origin.offset(rel));
				if (capturable(s)) {
					base.blocks.put(rel, s);
				}
			}
		}
		base.pending.clear();
	}

	// ---------------------------------------------------------------- wrench / wheel

	public static void link(ServerPlayer player, ServerLevel level, Entity ghast) {
		LINKS.put(player.getUUID(), ghast.getUUID());
		if (BASES.containsKey(ghast.getUUID())) {
			player.displayClientMessage(Component.literal("Wheel connected to this ghast."), true);
			return;
		}
		Base base = new Base(level, ghast);
		BASES.put(ghast.getUUID(), base);
		if (!regionLoaded(level, base.origin)) {
			player.displayClientMessage(Component.literal("Chunks around the ghast aren't loaded yet."), true);
			BASES.remove(ghast.getUUID());
			return;
		}

		// Starter deck so there is something to build against (only on empty cells).
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				BlockPos rel = new BlockPos(dx, Y0, dz);
				BlockPos abs = base.origin.offset(rel);
				if (level.getBlockState(abs).isAir()) {
					level.setBlock(abs, Blocks.OAK_PLANKS.defaultBlockState(), Block.UPDATE_ALL);
				}
			}
		}

		// Adopt anything already sitting on the deck level (also recovers a base after a server restart).
		Deque<BlockPos> queue = new ArrayDeque<>();
		for (int dx = -R; dx <= R; dx++) {
			for (int dz = -R; dz <= R; dz++) {
				BlockPos rel = new BlockPos(dx, Y0, dz);
				BlockState s = level.getBlockState(base.origin.offset(rel));
				if (capturable(s)) {
					base.blocks.put(rel, s);
					queue.add(rel);
				}
			}
		}
		while (!queue.isEmpty()) {
			BlockPos r = queue.poll();
			for (Direction d : Direction.values()) {
				BlockPos n = r.relative(d);
				if (!inRegion(n) || base.blocks.containsKey(n)) {
					continue;
				}
				BlockState s = level.getBlockState(base.origin.offset(n));
				if (capturable(s)) {
					base.blocks.put(n, s);
					queue.add(n);
				}
			}
		}
		player.displayClientMessage(
			Component.literal("Base created: build on the planks above the ghast. Hold the wheel's right-click to steer."), false);
	}

	public static void steer(ServerPlayer player) {
		UUID gid = LINKS.get(player.getUUID());
		Base base = gid == null ? null : BASES.get(gid);
		if (base == null) {
			player.displayClientMessage(Component.literal("This wheel isn't connected. Use the wrench on a happy ghast."), true);
			return;
		}
		Entity ghast = base.level.getEntity(gid);
		if (ghast == null || ghast.distanceTo(player) > 96) {
			player.displayClientMessage(Component.literal("The ghast is out of range."), true);
			return;
		}
		if (player.isShiftKeyDown()) {
			base.vel = base.vel.scale(0.3);
		} else {
			Vec3 v = base.vel.add(player.getLookAngle().scale(0.1));
			if (v.length() > MAX_SPEED) {
				v = v.normalize().scale(MAX_SPEED);
			}
			base.vel = v;
		}
	}

	public static void notePlacement(ServerLevel level, BlockHitResult hit) {
		BlockPos clicked = hit.getBlockPos();
		BlockPos placed = clicked.relative(hit.getDirection());
		for (Base b : BASES.values()) {
			if (b.level == level && b.blocks.containsKey(clicked.subtract(b.origin))) {
				b.pending.add(placed.subtract(b.origin));
			}
		}
	}

	// ---------------------------------------------------------------- per-tick movement

	public static void tick(MinecraftServer server) {
		Iterator<Map.Entry<UUID, Base>> it = BASES.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, Base> entry = it.next();
			Base base = entry.getValue();
			Entity ghast = base.level.getEntity(entry.getKey());
			if (ghast == null) {
				continue; // unloaded; keep the base, try again when it is back
			}
			if (!ghast.isAlive()) {
				it.remove(); // ghast died: the blocks simply stay where they are
				continue;
			}
			if (!regionLoaded(base.level, base.origin)) {
				continue;
			}
			processPending(base);

			// 1) steering: shift the base first, then move the ghast, so the ghast never bumps its own deck
			if (base.vel.lengthSqr() > 1.0E-5) {
				BlockPos predicted = originOf(ghast.position().add(base.vel));
				if (!predicted.equals(base.origin) && !tryShift(base, ghast, predicted)) {
					base.vel = Vec3.ZERO; // something solid is in the way
				} else {
					ghast.move(MoverType.SELF, base.vel);
					base.vel = base.vel.scale(0.9);
				}
			}

			// 2) reconcile (the ghast drifted, or was blocked by terrain while moving)
			BlockPos actual = originOf(ghast.position());
			if (!actual.equals(base.origin)) {
				if (!tryShift(base, ghast, actual)) {
					Vec3 p = base.lastGood;
					ghast.setPos(p.x, p.y, p.z);
					base.vel = Vec3.ZERO;
				}
			}
			if (originOf(ghast.position()).equals(base.origin)) {
				base.lastGood = ghast.position();
			}
		}
	}

	private static boolean tryShift(Base base, Entity ghast, BlockPos newOrigin) {
		ServerLevel level = base.level;
		if (!regionLoaded(level, newOrigin)
			|| newOrigin.getY() + Y0 < level.getMinY()
			|| newOrigin.getY() + Y0 + H > level.getMaxY()) {
			return false;
		}
		refresh(base);

		Set<BlockPos> oldAbs = new HashSet<>();
		for (BlockPos rel : base.blocks.keySet()) {
			oldAbs.add(base.origin.offset(rel));
		}
		for (BlockPos rel : base.blocks.keySet()) {
			BlockPos np = newOrigin.offset(rel);
			if (oldAbs.contains(np)) {
				continue;
			}
			BlockState s = level.getBlockState(np);
			if (!s.isAir() && !s.canBeReplaced()) {
				return false; // would overwrite terrain / someone else's build
			}
		}

		BlockPos delta = newOrigin.subtract(base.origin);
		AABB box = new AABB(
			base.origin.getX() - R, base.origin.getY() + Y0, base.origin.getZ() - R,
			base.origin.getX() + R + 1, base.origin.getY() + Y0 + H + 2, base.origin.getZ() + R + 1);
		List<Entity> carried = level.getEntities((Entity) null, box,
			e -> e != ghast && e.getRootVehicle() != ghast);

		BlockState air = Blocks.AIR.defaultBlockState();
		for (BlockPos abs : oldAbs) {
			level.setBlock(abs, air, FLAGS);
		}
		for (Map.Entry<BlockPos, BlockState> e : base.blocks.entrySet()) {
			level.setBlock(newOrigin.offset(e.getKey()), e.getValue(), FLAGS);
		}
		for (Entity e : carried) {
			e.teleportRelative(delta.getX(), delta.getY(), delta.getZ());
		}
		base.origin = newOrigin;
		return true;
	}
}
