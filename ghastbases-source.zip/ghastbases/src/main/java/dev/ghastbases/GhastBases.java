package dev.ghastbases;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class GhastBases implements ModInitializer {
	public static final String MOD_ID = "ghastbases";

	public static Item WRENCH;
	public static Item WHEEL;

	private static Item register(String name) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, name));
		return Registry.register(BuiltInRegistries.ITEM, key, new Item(new Item.Properties().setId(key).stacksTo(1)));
	}

	@Override
	public void onInitialize() {
		WRENCH = register("wrench");
		WHEEL = register("wheel");

		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(output -> {
			output.accept(WRENCH);
			output.accept(WHEEL);
		});

		// Wrench + right-click a happy ghast: link it (and create/adopt its base).
		UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			ItemStack held = player.getItemInHand(hand);
			if (!held.is(WRENCH) || entity.getType() != EntityType.HAPPY_GHAST) {
				return InteractionResult.PASS;
			}
			if (!world.isClientSide()) {
				BaseManager.link((ServerPlayer) player, (ServerLevel) world, entity);
			}
			return InteractionResult.SUCCESS;
		});

		// Wheel + hold right-click: steer the linked ghast toward where you look. Sneak to brake.
		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (!player.getItemInHand(hand).is(WHEEL)) {
				return InteractionResult.PASS;
			}
			if (!world.isClientSide()) {
				BaseManager.steer((ServerPlayer) player);
			}
			return InteractionResult.SUCCESS;
		});

		// Blocks placed against the base become part of the base.
		UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
			if (!world.isClientSide() && player.getItemInHand(hand).getItem() instanceof BlockItem) {
				BaseManager.notePlacement((ServerLevel) world, hit);
			}
			return InteractionResult.PASS;
		});

		ServerTickEvents.END_SERVER_TICK.register(BaseManager::tick);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> BaseManager.clear());
	}
}
