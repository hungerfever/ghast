# Ghast Bases (Fabric, Minecraft 26.3)

Build a base on a happy ghast and fly it around.

## Build the .mrpack

1. Install JDK 25 and Python 3.
2. In this folder run: `python make_mrpack.py`
3. In the Modrinth App: Add instance > Import from file > pick `ghastbases-1.0.0.mrpack`.

If Gradle reports compile errors (this was written without being able to compile it), send them back and they get fixed.

## How to play

- **Wrench** (iron: `I I` / ` I ` / ` I `) and **Ship's Wheel** (sticks + iron: ` S ` / `SIS` / ` S `), also in the creative Tools tab.
- Right-click a happy ghast with the **wrench**: links your wheel to it and creates a 5x5 plank deck above it.
- Place blocks against the deck: they become part of the base and ride along (13x13 footprint, 12 tall).
- Hold right-click with the **wheel**: the ghast flies toward where you look. Sneak + right-click brakes.

## Limits

- Blocks with block entities (chests, furnaces, signs) and fluids are not carried.
- The base stops when it would hit terrain.
- Links are kept in memory: after a server restart, use the wrench on the ghast again (it re-adopts the blocks on the deck level).
- Link while the ghast hovers in open air, so the adopt step doesn't grab terrain.
